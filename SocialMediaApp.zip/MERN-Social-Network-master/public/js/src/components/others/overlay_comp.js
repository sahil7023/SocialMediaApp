import React from 'react'

const overlay = () => (
    <div class='overlay' ></div>
)

export default overlay