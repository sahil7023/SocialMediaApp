// eveything before user is not logged in
import './login'

// profile component
import './components/profile/profile_main'

// edit component
import './components/edit/edit_main'

// home component
import './components/home/home_main'

// explore component
import './components/explore/explore_main'